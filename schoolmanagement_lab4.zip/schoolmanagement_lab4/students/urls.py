from django.urls import path
from . import views
urlpatterns=[
    path('',views.home,name="home"),
    # path('home/',views.home,name="home"),
    path('edit/',views.edit_students,name='edit'),
    path('show/',views.list_students,name='show'),
    path('delete/',views.delete_students,name='delete'),
    path('students/', views.students_list, name='students'),

]
