# في ملف students/models.py
from django.db import models

class Students(models.Model):
    levels = [('1', '1'), ('2', '2'), ('3', '3'), ('4', '4')]
    
    f_name = models.CharField(max_length=10, default="Student")
    l_name = models.CharField(max_length=10, default="Student")
    age = models.IntegerField()
    level = models.CharField(choices=levels, max_length=20)
    gpa = models.DecimalField(max_digits=4, decimal_places=2)
    statust = models.BooleanField(null=False)
    reportet = models.TextField(max_length=300)
    
    #--------------------
    # profile_picture = models.ImageField(upload_to='students/', null=True, blank=True)

    def __str__(self):
        return f"{self.f_name} {self.l_name}"
    