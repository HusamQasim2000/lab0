# في ملف students/admin.py
from django.contrib import admin
from .models import Students

# تسجيل النموذج في لوحة الإدارة
admin.site.register(Students)